<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php
  // Optional: pass $scope to make DOM unique per tab ('students' | 'bulk')
  $scope = isset($scope) && $scope ? preg_replace('/[^a-zA-Z0-9_]/','', (string)$scope) : 'mail';
  $ajax_get_tpl = admin_url('internship_management/internship_mail/ajax_get_template');
?>
<div class="panel_s">
  <div class="panel-body">
    <div class="row">
      <div class="col-md-6">
        <label>Mẫu Email</label>
        <select class="form-control js-tpl-select" name="template_id"
                data-scope="<?php echo html_escape($scope); ?>"
                data-url="<?php echo html_escape($ajax_get_tpl); ?>">
          <option value="">-- Chọn mẫu --</option>
          <?php if(!empty($templates)): foreach($templates as $t): ?>
            <option value="<?php echo (int)$t['id']; ?>"><?php echo '#'.(int)$t['id'].' - '.html_escape($t['name']); ?></option>
          <?php endforeach; endif; ?>
        </select>
        <small class="text-muted">Chọn template → tự nạp Subject + HTML. (Bạn vẫn có thể chỉnh sửa trước khi gửi)</small>
      </div>
      <div class="col-md-6">
        <label>Tiêu đề (Subject) – tuỳ chọn</label>
        <input type="text" class="form-control js-mail-subject" name="subject"
               placeholder="Để trống → dùng title của template"
               value="<?php echo html_escape($subject ?? ''); ?>">
      </div>
    </div>

    <hr class="hr-panel-heading" />

    <div class="row">
      <div class="col-md-12">
        <div class="mbot10" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
          <button type="button" class="btn btn-default js-btn-load-tpl">
            <i class="fa fa-download"></i> Nạp nội dung từ template
          </button>
          <button type="button" class="btn btn-default js-btn-copy-html">
            <i class="fa fa-copy"></i> Copy HTML
          </button>
          <span class="text-muted">Preview bên phải dùng dữ liệu demo.</span>
        </div>
      </div>

      <div class="col-md-6">
        <label>Nội dung Email (HTML)</label>
        <textarea class="form-control js-mail-body" name="body" rows="18"
                  placeholder="HTML email..."><?php echo html_escape($body ?? ''); ?></textarea>
      </div>

      <div class="col-md-6">
        <label>Preview (render token demo)</label>
        <div class="well js-preview" style="min-height: 420px;background:#fff"></div>
      </div>
    </div>

    <hr class="hr-panel-heading" />

    <div class="row">
      <div class="col-md-12">
        <label>Tokens gợi ý</label>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <?php
            $tokens = $tokens ?? [
              '{{student.name}}','{{student.email}}','{{student.phone}}','{{student.school}}','{{student.major}}',
              '{{job.id}}','{{job.company}}','{{job.major}}','{{job.round}}','{{job.interview_date}}',
              '{{today}}'
            ];
            foreach($tokens as $tk):
          ?>
            <span class="label label-default" style="cursor:pointer" onclick="navigator.clipboard.writeText('<?php echo addslashes($tk); ?>')"><?php echo html_escape($tk); ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

  </div>
</div>

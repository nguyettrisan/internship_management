<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<style>
.ifk-wrap{max-width:1600px;margin:0 auto}
.ifk-tabs .nav-tabs>li>a{font-weight:800}
.ifk-card{background:#fff;border-radius:14px;border:1px solid #e5e7eb;box-shadow:0 10px 30px rgba(2,6,23,.06);padding:16px}
.ifk-flex{display:flex;gap:12px;flex-wrap:wrap;align-items:center}
.ifk-right{margin-left:auto}
.ifk-muted{color:#6b7280}
.ifk-recipients{border:1px solid #e5e7eb;border-radius:12px;overflow:hidden}
.ifk-recipients-hd{padding:10px 12px;background:#f8fafc;border-bottom:1px solid #e5e7eb;display:flex;gap:10px;align-items:center}
.ifk-recipients-bd{max-height:320px;overflow:auto;padding:8px 12px}
.ifk-rec-row{display:flex;gap:10px;align-items:center;padding:6px 0;border-bottom:1px dashed rgba(15,23,42,.10)}
.ifk-rec-row:last-child{border-bottom:none}
.ifk-badge{display:inline-block;padding:2px 8px;border-radius:999px;background:#eef2ff;color:#3730a3;font-weight:800;font-size:12px}
</style>

<?php
  $csrf_name = $this->security->get_csrf_token_name();
  $csrf_hash = $this->security->get_csrf_hash();
?>

<div id="wrapper">
  <div class="content">
    <div class="ifk-wrap">
      <div class="row">
        <div class="col-md-12">
          <div class="ifk-card">
            <div class="ifk-flex mbot15">
              <h3 class="m0"><i class="fa fa-envelope"></i> Gửi Email Internship</h3>
              <a class="btn btn-default ifk-right" href="<?php echo admin_url('internship_management/internship_mail/settings'); ?>">
                <i class="fa fa-cog"></i> Cài đặt Email
              </a>
            </div>

            <div class="ifk-tabs">
              <ul class="nav nav-tabs">
                <li class="active"><a href="#tab_students" data-toggle="tab">Gửi học sinh</a></li>
                <li><a href="#tab_job" data-toggle="tab">Gửi theo đơn tuyển</a></li>
              </ul>

              <div class="tab-content" style="padding-top:14px">

                <!-- ===================== TAB 1: STUDENTS ===================== -->
                <div class="tab-pane active" id="tab_students">

                  <form method="post" action="<?php echo admin_url('internship_management/internship_mail/do_send_students'); ?>">
                    <input type="hidden" name="<?php echo html_escape($csrf_name); ?>" value="<?php echo html_escape($csrf_hash); ?>">
                    <input type="hidden" name="tab" value="students">

                    <!-- RECIPIENTS FIRST -->
                    <div class="panel_s">
                      <div class="panel-body">
                        <h4 class="m0 mbot10">Chọn thông tin gửi</h4>

                        <div class="row">
                          <div class="col-md-12">
                            <label>Chọn sinh viên (có thể chọn nhiều)</label>
                            <select class="form-control select2 select2-students" name="student_ids[]" multiple="multiple" style="width:100%">
                              <?php if(!empty($students)): foreach($students as $s): ?>
                                <option value="<?php echo (int)$s['id']; ?>">
                                  <?php echo html_escape(($s['full_name'] ?? $s['name'] ?? '')); ?> - <?php echo html_escape($s['email'] ?? ''); ?>
                                </option>
                              <?php endforeach; endif; ?>
                            </select>
                            <p class="ifk-muted mtop5">Gợi ý: có thể gõ tìm kiếm (Select2) – dùng ajax khi dữ liệu lớn.</p>
                          </div>
                        </div>

                        <div class="row mtop10">
                          <div class="col-md-4">
                            <div class="checkbox checkbox-primary">
                              <input type="checkbox" id="dry_students" name="dry_run" value="1" checked>
                              <label for="dry_students"><strong>DRY RUN</strong> (không gửi thật – chỉ đếm/log)</label>
                            </div>
                          </div>
                          <div class="col-md-8 text-right">
                            <button type="submit" class="btn btn-primary">
                              <i class="fa fa-paper-plane"></i> Gửi / Thực thi
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- TEMPLATE + HTML -->
                    <?php $scope = 'students'; $subject = ''; $body = ''; $tokens = $tokens_students ?? null; $this->load->view('internship_management/mail/_common_fields', get_defined_vars()); ?>

                  </form>
                </div>

                <!-- ===================== TAB 2: JOB ORDER BULK ===================== -->
                <div class="tab-pane" id="tab_job">

                  <form method="post" action="<?php echo admin_url('internship_management/internship_mail/do_send_job_order'); ?>" id="formBulk">
                    <input type="hidden" name="<?php echo html_escape($csrf_name); ?>" value="<?php echo html_escape($csrf_hash); ?>">
                    <input type="hidden" name="tab" value="job">

                    <!-- RECIPIENTS FIRST -->
                    <div class="panel_s">
                      <div class="panel-body">
                        <h4 class="m0 mbot10">Chọn thông tin gửi</h4>

                        <div class="row">
                          <div class="col-md-6">
                            <label>Chọn đơn tuyển</label>
                            <select class="form-control select2" name="job_order_id" id="jobOrderSelect" style="width:100%">
                              <option value="">-- Chọn đơn tuyển --</option>
                              <?php if(!empty($job_orders)): foreach($job_orders as $j): ?>
                                <option value="<?php echo (int)$j['id']; ?>">
                                  <?php
                                    $name = '#'.(int)$j['id'].' - '.($j['company_name_vi'] ?? $j['company_name'] ?? '');
                                    $name .= !empty($j['major_vi']) ? ' ('.$j['major_vi'].')' : '';
                                    echo html_escape($name);
                                  ?>
                                </option>
                              <?php endforeach; endif; ?>
                            </select>

                            <div class="alert alert-warning mtop10" style="margin-bottom:10px">
                              <i class="fa fa-shield"></i>
                              <strong>An toàn:</strong> luôn Load + tick chọn trước khi gửi. Nên bật <strong>DRY RUN</strong> để kiểm tra danh sách &amp; số lượng.
                            </div>

                            <button type="button" class="btn btn-info btn-block" id="btnLoadRecipients">
                              <i class="fa fa-users"></i> Load danh sách recipients (checkbox)
                            </button>

                            <label class="mtop15">Nhập email thủ công (tuỳ chọn)</label>
                            <textarea class="form-control" name="manual_emails" rows="4"
                                      placeholder="vd: a@x.com, b@y.com hoặc mỗi dòng 1 email"></textarea>
                            <p class="ifk-muted mtop5">Tách bằng xuống dòng, dấu phẩy , hoặc chấm phẩy ;</p>

                            <div class="checkbox checkbox-primary">
                              <input type="checkbox" id="dry_bulk" name="dry_run" value="1" checked>
                              <label for="dry_bulk"><strong>DRY RUN</strong> (không gửi thật – chỉ log/đếm)</label>
                            </div>

                            <label class="mtop10">Xác nhận chống gửi nhầm</label>
                            <input type="text" class="form-control" name="confirm_send" id="confirmSend" placeholder="Gõ: SEND để mở nút 'Gửi'">
                            <p class="ifk-muted mtop5">Chỉ gửi thật khi gõ đúng <strong>SEND</strong> và đã tick chọn recipients.</p>

                            <button type="submit" class="btn btn-success btn-block" id="btnSubmitBulk" disabled>
                              <i class="fa fa-paper-plane"></i> Gửi / Thực thi
                            </button>
                          </div>

                          <div class="col-md-6">
                            <div class="ifk-recipients">
                              <div class="ifk-recipients-hd">
                                <label class="checkbox-inline m0">
                                  <input type="checkbox" id="chkAllRecipients"> Chọn tất cả
                                </label>
                                <span class="ifk-muted">Tổng: <span id="recTotal">0</span> • Đã chọn: <span id="recSelected">0</span></span>
                                <input type="text" class="form-control input-sm ifk-right" id="recSearch" placeholder="Tìm email/tên..." style="max-width:220px">
                              </div>
                              <div class="ifk-recipients-bd" id="recipientsWrap">
                                <div class="ifk-muted">Chưa load recipients...</div>
                              </div>
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>

                    <!-- TEMPLATE + HTML -->
                    <?php $scope = 'bulk'; $subject = ''; $body = ''; $tokens = $tokens_bulk ?? null; $this->load->view('internship_management/mail/_common_fields', get_defined_vars()); ?>

                  </form>
                </div>

              </div><!-- /tab-content -->
            </div><!-- /tabs -->

          </div><!-- /card -->
        </div>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  // ===== CSRF =====
  const CSRF_NAME = <?php echo json_encode($csrf_name); ?>;
  let CSRF_HASH = <?php echo json_encode($csrf_hash); ?>;

  function ajaxPost(url, data){
    data = data || {};
    data[CSRF_NAME] = CSRF_HASH;
    return $.ajax({url:url, type:'POST', data:data, dataType:'json'})
      .done(function(res){
        // Some apps rotate CSRF token: accept from response if present
        if(res && res.csrf_hash){ CSRF_HASH = res.csrf_hash; }
      });
  }

  // ===== Select2 =====
  $(function(){
    $('.select2').select2({width:'100%'});
  });

  // ===== Template auto-load + preview =====
  function renderDemo(html){
    // Basic demo data
    const demo = {
      'student.name':'KH Demo',
      'student.email':'demo@example.com',
      'student.phone':'0900 000 000',
      'student.school':'Đại học Demo',
      'student.major':'Ngành Demo',
      'job.id':'#DEMO',
      'job.company':'Công ty Demo',
      'job.major':'Ngành Demo',
      'job.round':'1',
      'job.interview_date':'01/01/2026',
      'today': new Date().toLocaleDateString('vi-VN')
    };
    return (html || '').replace(/\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}/g, function(_,k){
      return demo[k] !== undefined ? demo[k] : '{{'+k+'}}';
    });
  }

  function updatePreview($form){
    const $body = $form.find('.js-mail-body');
    const $pv   = $form.find('.js-preview');
    if(!$body.length || !$pv.length) return;
    const html = $body.val() || '';
    $pv.html(renderDemo(html));
  }

  function loadTemplate($form, force){
    const $sel = $form.find('.js-tpl-select');
    const tplId = $sel.val();
    const url = $sel.data('url');
    if(!tplId){ return; }

    return ajaxPost(url, {id: tplId}).done(function(res){
      if(!res || !res.ok){ alert(res && res.message ? res.message : 'Không lấy được template'); return; }
      const subj = (res.subject || '').toString();
      const body = (res.body || '').toString();

      const $subj = $form.find('.js-mail-subject');
      const $body = $form.find('.js-mail-body');

      if(force || !$subj.val()){
        $subj.val(subj);
      }
      if(force || !$body.val()){
        $body.val(body);
      } else {
        // user already typed body -> still update preview only
      }
      updatePreview($form);
    }).fail(function(){
      alert('Lỗi AJAX khi lấy template');
    });
  }

  $(document).on('change', '.js-tpl-select', function(){
    const $form = $(this).closest('form');
    loadTemplate($form, true); // auto: always load
  });

  $(document).on('click', '.js-btn-load-tpl', function(){
    const $form = $(this).closest('form');
    loadTemplate($form, true);
  });

  $(document).on('click', '.js-btn-copy-html', function(){
    const $form = $(this).closest('form');
    const v = $form.find('.js-mail-body').val() || '';
    navigator.clipboard.writeText(v);
    alert('Đã copy HTML');
  });

  $(document).on('input', '.js-mail-body', function(){
    updatePreview($(this).closest('form'));
  });

  // Initialize preview for both forms
  $(function(){
    $('form').each(function(){ updatePreview($(this)); });
  });

  // ===== Bulk recipients loader =====
  const loadUrl = <?php echo json_encode(admin_url('internship_management/internship_mail/ajax_load_recipients')); ?>;

  function setRecipients(list){
    const $wrap = $('#recipientsWrap');
    if(!list || !list.length){
      $wrap.html('<div class="ifk-muted">Không có recipients...</div>');
      $('#recTotal').text('0'); $('#recSelected').text('0'); $('#chkAllRecipients').prop('checked', false);
      toggleBulkSubmit();
      return;
    }
    let html = '';
    list.forEach(function(r){
      const id = (r.id || '');
      const email = (r.email || '');
      const name  = (r.name || '');
      html += '<div class="ifk-rec-row" data-name="'+escapeHtml(name)+'" data-email="'+escapeHtml(email)+'">'+
                '<label class="checkbox-inline m0">'+
                  '<input class="rec-chk" type="checkbox" name="recipient_ids[]" value="'+id+'"> '+
                  '<strong>'+escapeHtml(name)+'</strong> <span class="ifk-muted">- '+escapeHtml(email)+'</span>'+
                '</label>'+
              '</div>';
    });
    $wrap.html(html);
    $('#recTotal').text(list.length);
    $('#recSelected').text('0');
    $('#chkAllRecipients').prop('checked', false);
    toggleBulkSubmit();
  }

  function escapeHtml(s){
    return String(s||'').replace(/[&<>"']/g, function(m){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]);
    });
  }

  $('#btnLoadRecipients').on('click', function(){
    const jobId = $('#jobOrderSelect').val();
    if(!jobId){ alert('Vui lòng chọn đơn tuyển'); return; }
    $(this).prop('disabled', true).text('Đang load...');
    ajaxPost(loadUrl, {job_order_id: jobId}).done(function(res){
      if(!res || !res.ok){
        alert(res && res.message ? res.message : 'Không load được recipients');
        setRecipients([]);
        return;
      }
      setRecipients(res.recipients || []);
    }).fail(function(){
      alert('Lỗi AJAX khi load recipients');
      setRecipients([]);
    }).always(function(){
      $('#btnLoadRecipients').prop('disabled', false).html('<i class="fa fa-users"></i> Load danh sách recipients (checkbox)');
    });
  });

  // Search recipients
  $('#recSearch').on('input', function(){
    const q = ($(this).val() || '').toLowerCase().trim();
    $('#recipientsWrap .ifk-rec-row').each(function(){
      const name = ($(this).data('name') || '').toLowerCase();
      const email= ($(this).data('email') || '').toLowerCase();
      const ok = !q || name.includes(q) || email.includes(q);
      $(this).toggle(ok);
    });
  });

  // Select all
  $('#chkAllRecipients').on('change', function(){
    const on = $(this).is(':checked');
    $('#recipientsWrap .rec-chk:visible').prop('checked', on).trigger('change');
  });

  // Count selected
  $(document).on('change', '.rec-chk', function(){
    const sel = $('#recipientsWrap .rec-chk:checked').length;
    $('#recSelected').text(sel);
    toggleBulkSubmit();
  });

  // Confirm SEND + recipients + dry_run off => enable submit
  function toggleBulkSubmit(){
    const confirmOk = ($('#confirmSend').val() || '').trim().toUpperCase() === 'SEND';
    const anyRec = $('#recipientsWrap .rec-chk:checked').length > 0;
    const dry = $('#dry_bulk').is(':checked');
    // allow submit always if DRY RUN (no need SEND), but still need recipients OR manual_emails?
    const manual = ($('textarea[name="manual_emails"]').val() || '').trim().length > 0;
    const hasTarget = anyRec || manual;

    const enable = hasTarget && (dry || confirmOk);
    $('#btnSubmitBulk').prop('disabled', !enable);
  }

  $('#confirmSend, #dry_bulk, textarea[name="manual_emails"]').on('input change', toggleBulkSubmit);
  $(function(){ toggleBulkSubmit(); });

})();
</script>

<?php init_tail(); ?>

<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>

<style>
    .ifk-title {
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 15px;
        color: #1b3358;
    }

    .panel_s {
        border-radius: 10px;
        border: 1px solid #e8ecf3;
    }

    .form-control {
        border-radius: 6px !important;
    }

    .tox-tinymce {
        border-radius: 6px !important;
        overflow: hidden !important;
        border: 1px solid #dce1e7 !important;
    }

    .table-responsive {
        border-radius: 10px;
        border: 1px solid #eceff3;
        overflow-x: auto;
    }
</style>

<div id="wrapper">
    <div class="content">

        <div class="row">
            <div class="col-md-12">

                <!-- FORM EDIT / ADD TEMPLATE -->
                <div class="panel_s">
                    <div class="panel-body">

                        <div class="ifk-title">
                            <i class="fa fa-envelope"></i> Mẫu Email Internship
                        </div>

                        <?php echo form_open(admin_url('internship_management/internship_mail/email_templates')); ?>

                        <input type="hidden" name="id"
                               value="<?php echo isset($edit_tpl) ? $edit_tpl->id : ''; ?>">

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Tên mẫu</label>
                                    <input type="text" name="name" class="form-control"
                                           value="<?php echo isset($edit_tpl) ? $edit_tpl->name : ''; ?>"
                                           required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Mã (code)</label>
                                    <input type="text" name="code" class="form-control"
                                           value="<?php echo isset($edit_tpl) ? $edit_tpl->code : ''; ?>"
                                           required>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Tiêu đề email</label>
                                    <input type="text" name="subject" class="form-control"
                                           value="<?php echo isset($edit_tpl) ? $edit_tpl->subject : ''; ?>"
                                           required>
                                </div>
                            </div>

                            <div class="col-md-12 form-group">
                                <label>Nội dung email</label>
                                <?php echo render_textarea(
                                    'body_html',
                                    '',
                                    isset($edit_tpl) ? $edit_tpl->body_html : '',
                                    [],
                                    [],
                                    '',
                                    'tinymce'
                                ); ?>
                            </div>

                            <div class="col-md-12 mtop10">
                                <label>
                                    <input type="checkbox" name="active"
                                        <?php echo (isset($edit_tpl) && $edit_tpl->active == 1) ? 'checked' : ''; ?>>
                                    Kích hoạt mẫu
                                </label>
                            </div>

                            <div class="col-md-12 text-right mtop20">
                                <button class="btn btn-primary">
                                    <i class="fa fa-save"></i> Lưu mẫu
                                </button>
                            </div>

                        </div>

                        <?php echo form_close(); ?>

                    </div>
                </div>

                <!-- LIST TABLE -->
                <div class="panel_s">
                    <div class="panel-body">

                        <div class="ifk-title">Danh sách mẫu Email</div>

                        <div class="table-responsive">
                            <table class="table dt-table">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tên mẫu</th>
                                    <th>Mã</th>
                                    <th>Tiêu đề</th>
                                    <th>Kích hoạt</th>
                                    <th>Ngày tạo</th>
                                    <th>Thao tác</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php foreach ($templates as $tpl) { ?>
                                    <tr>
                                        <td><?php echo $tpl->id; ?></td>
                                        <td><?php echo $tpl->name; ?></td>
                                        <td><code><?php echo $tpl->code; ?></code></td>
                                        <td><?php echo $tpl->subject; ?></td>

                                        <td>
                                            <?php echo $tpl->active
                                                ? "<span class='label label-success'>Bật</span>"
                                                : "<span class='label label-default'>Tắt</span>"; ?>
                                        </td>

                                        <td><?php echo $tpl->date_created; ?></td>

                                        <td>
                                            <a href="<?php echo admin_url('internship_management/internship_mail/email_templates?id=' . $tpl->id); ?>"
                                               class="btn btn-default btn-icon">
                                                <i class="fa fa-edit"></i>
                                            </a>

                                            <a href="<?php echo admin_url('internship_management/internship_mail/delete_template/' . $tpl->id); ?>"
                                               class="btn btn-danger btn-icon _delete">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>

                            </table>
                        </div>

                    </div>
                </div>

            </div>
        </div>

    </div>
</div>

<?php init_tail(); ?>
</body>
</html>
<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>

<div id="wrapper">
<div class="content">

    <div class="panel_s">
    <div class="panel-body">

        <h4 class="bold">
            <i class="fa fa-cog"></i> Cài đặt Internship Japan
        </h4>
        <hr>

        <?= form_open_multipart(); ?>

        <div class="row">

            <!-- 1) SMTP SETTINGS -->
            <div class="col-md-12">
                <h5 class="bold text-primary mtop20">1) Cấu hình SMTP</h5>
                <hr>
            </div>

            <div class="col-md-6">
                <?= render_input('smtp_host', 'SMTP Host', $smtp_host); ?>
            </div>

            <div class="col-md-3">
                <?= render_input('smtp_port', 'SMTP Port', $smtp_port); ?>
            </div>

            <div class="col-md-3">
                <?php 
                    echo render_select(
                        'smtp_secure',
                        [
                            ['id'=>'tls', 'name'=>'TLS'],
                            ['id'=>'ssl', 'name'=>'SSL'],
                            ['id'=>'none','name'=>'Không mã hoá']
                        ],
                        ['id','name'],
                        'Mã hoá',
                        $smtp_secure
                    );
                ?>
            </div>

            <div class="col-md-6">
                <?= render_input('smtp_user', 'SMTP Username', $smtp_user); ?>
            </div>

            <div class="col-md-6">
                <?= render_input('smtp_pass', 'SMTP Password', $smtp_pass); ?>
            </div>

            <div class="col-md-6">
                <?= render_input('sender_name', 'Tên người gửi', $sender_name); ?>
            </div>

            <div class="col-md-6">
                <?= render_input('sender_email', 'Email người gửi', $sender_email); ?>
            </div>


            <!-- 2) BRANDING -->
            <div class="col-md-12 mtop30">
                <h5 class="bold text-primary">2) Giao diện Email (Branding)</h5>
                <hr>
            </div>

            <div class="col-md-6">
                <label class="control-label">Logo thương hiệu</label><br>
                <input type="file" name="brand_logo" class="form-control">

                <?php if ($brand_logo): ?>
                <div class="mtop10">
                    <img src="<?= base_url($brand_logo); ?>" style="height:70px;border:1px solid #ddd;padding:4px;">
                </div>
                <?php endif; ?>
            </div>

            <div class="col-md-3">
                <label class="control-label">Màu chủ đạo</label>
                <input type="color" name="brand_color" class="form-control"
                       value="<?= $brand_color ?>" style="height:50px;padding:0;">
            </div>

            <div class="col-md-3">
                <label class="control-label">Màu nền Email</label>
                <input type="color" name="background_color" class="form-control"
                       value="<?= $background_color ?>" style="height:50px;padding:0;">
            </div>


            <!-- 3) AUTO EMAIL -->
            <div class="col-md-12 mtop30">
                <h5 class="bold text-primary">3) Tự động gửi Email</h5>
                <hr>
            </div>

            <div class="col-md-4">
                <label>
                    <input type="checkbox" name="auto_email_entry" value="1" <?= $auto_email_entry ? 'checked' : '' ?>>
                    Gửi Email trước nhập cảnh 7 ngày
                </label>
            </div>

            <div class="col-md-4">
                <label>
                    <input type="checkbox" name="auto_email_return" value="1" <?= $auto_email_return ? 'checked' : '' ?>>
                    Gửi Email trước về nước 30 ngày
                </label>
            </div>

            <div class="col-md-4">
                <label>
                    <input type="checkbox" name="auto_email_survey" value="1" <?= $auto_email_survey ? 'checked' : '' ?>>
                    Gửi khảo sát định kỳ
                </label>
            </div>


            <!-- 4) GOOGLE AI API -->
            <div class="col-md-12 mtop30">
                <h5 class="bold text-primary">4) Google AI API (Sinh dữ liệu tự động)</h5>
                <hr>
            </div>

            <div class="col-md-6">
                <?= render_input('google_api_key', 'Google AI API Key', $google_api_key); ?>
            </div>

            <div class="col-md-6">
                <?php
                   $models = [
    ['id' => 'gemini-1.5-flash', 'name' => 'Gemini 1.5 Flash (nhanh - tiết kiệm)'],
    ['id' => 'gemini-1.5-pro',   'name' => 'Gemini 1.5 Pro (chất lượng cao nhất)']
];
                ?>
               <?= render_select('google_ai_model', $models, ['id', 'name'], 'Chọn Model AI', $google_ai_model); ?>
            </div>

            <div class="col-md-12">
                <a href="javascript:void(0)" class="btn btn-info mtop10" onclick="testAPI()">
                    <i class="fa fa-vial"></i> Kiểm tra kết nối API
                </a>
                <div id="api_result" class="mtop10 text-info"></div>
            </div>

        </div>

        <hr>
        <div class="text-right">
            <button class="btn btn-primary">
                <i class="fa fa-save"></i> Lưu cài đặt
            </button>
        </div>

        <?= form_close(); ?>

    </div>
    </div>

</div>
</div>

<script>
function testAPI() {
    $('#api_result').html('Đang kiểm tra...');

    $.post('<?= admin_url("internship_management/internship_settings/test_api") ?>', {}, function(r){
        $('#api_result').html(r);
    }).fail(function() {
        $('#api_result').html("<span class='text-danger'>❌ Không kết nối được API</span>");
    });
}
</script>

<?php init_tail(); ?>
</body>
</html>